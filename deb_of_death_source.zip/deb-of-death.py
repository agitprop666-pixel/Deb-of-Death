#!/usr/bin/env python3
"""
Debian Package Creator - Professional PyQt6 Application
Creates .deb packages from executables with modern GUI interface
"""

import sys
import os
import stat
import shutil
import subprocess
import tempfile
import time
import re
from pathlib import Path
from typing import Optional

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, QGridLayout,
    QWidget, QLabel, QLineEdit, QTextEdit, QPushButton, QFileDialog,
    QProgressBar, QFrame, QScrollArea, QTabWidget, QGroupBox,
    QComboBox, QSpinBox, QCheckBox, QMessageBox, QSplitter, QSplashScreen
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QPropertyAnimation, QEasingCurve, QRect, QTimer
from PyQt6.QtGui import QFont, QIcon, QPalette, QColor, QPixmap, QPainter, QLinearGradient


class DebOfDeathSplash:
    """Splash screen for Deb of Death application"""
    
    @staticmethod
    def create_splash():
        """Create the splash screen using the professional skull image with title overlay"""
        try:
            # Check for the external splash.png file
            splash_path = Path(__file__).parent / "splash.png"
            
            if splash_path.exists():
                pixmap = QPixmap(str(splash_path))
                if pixmap.isNull():
                    pixmap = QPixmap(800, 600)
                    pixmap.fill(QColor(20, 20, 20))
                if pixmap.width() != 800 or pixmap.height() != 600:
                    pixmap = pixmap.scaled(800, 600, Qt.AspectRatioMode.KeepAspectRatio,
                                           Qt.TransformationMode.SmoothTransformation)
                painter = QPainter(pixmap)
                painter.setPen(QColor(255, 255, 255))
                painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
                text_rect = pixmap.rect(); text_rect.setTop(40); text_rect.setBottom(100)
                painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, "Deb of Death")
                painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
                footer_rect = pixmap.rect(); footer_rect.setTop(pixmap.height() - 100); footer_rect.setBottom(pixmap.height() - 50)
                painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, "Death's Head Software")
                painter.end()
                return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
            else:
                # Fallback to generated splash if image not found
                return DebOfDeathSplash._create_fallback_splash()
                
        except Exception as e:
            print(f"Splash error: {e}")
            return DebOfDeathSplash._create_fallback_splash()
    
    @staticmethod
    def _create_fallback_splash():
        """Create fallback splash with ASCII art if image not available"""
        try:
            # Generate dark-themed screen with ASCII art skull as fallback
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(15, 15, 35))  # Dark background to match app theme
            
            painter = QPainter(pixmap)
            
            # Title
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect()
            text_rect.setTop(40)
            text_rect.setBottom(100)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, "Deb of Death")

            # ASCII skull art
            painter.setFont(QFont("Courier", 14))
            skull_art = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            y_start = 250
            for i, line in enumerate(skull_art):
                painter.drawText(250, y_start + (i * 25), line)

            # Footer
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect()
            footer_rect.setTop(pixmap.height() - 50)
            footer_rect.setBottom(pixmap.height())
            painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, "Death's Head Software")

            painter.end()
            
            return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
            
        except Exception as e:
            print(f"Fallback splash error: {e}")
            return None
    
    @staticmethod
    def show_splash_sequence(splash, app):
        """Show animated splash sequence with loading messages"""
        if not splash:
            return
            
        splash.show()
        
        # Loading messages with death/cybersecurity theme
        loading_messages = [
            "Initializing Death Protocols...",
            "Loading Package Arsenal...",
            "Scanning for Dependencies...", 
            "Preparing Debian Weapons...",
            "Activating Build Chambers...",
            "Ready to Terminate Bad Packages!"
        ]
        
        for i, msg in enumerate(loading_messages):
            # Position message at bottom with some padding
            splash.showMessage(
                "\n\n\n\n\n\n\n\n\n\n\n\n" + msg, 
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter, 
                QColor(255, 255, 255)  # White text for loading messages
            )
            app.processEvents()
            time.sleep(0.7)  # Slightly slower for dramatic effect


class PackageBuilder(QThread):
    """Background thread for building Debian packages"""
    
    progress_updated = pyqtSignal(int, str)
    build_completed = pyqtSignal(bool, str)
    
    def __init__(self, package_data: dict, executable_path: str, output_dir: str):
        super().__init__()
        self.package_data = package_data
        self.executable_path = executable_path
        self.output_dir = output_dir
    
    def run(self):
        try:
            self.progress_updated.emit(10, "Creating package structure...")
            
            # Create temporary build directory
            with tempfile.TemporaryDirectory() as temp_dir:
                package_dir = Path(temp_dir) / f"{self.package_data['name']}_{self.package_data['version']}"
                package_dir.mkdir()
                
                self.progress_updated.emit(20, "Setting up DEBIAN directory...")
                
                # Create DEBIAN directory
                debian_dir = package_dir / "DEBIAN"
                debian_dir.mkdir()
                
                # Create control file
                control_content = self._generate_control_file()
                (debian_dir / "control").write_text(control_content)
                
                # Create simplified but effective postinst script
                if self.package_data.get('create_desktop_entry', False):
                    postinst_content = """#!/bin/bash
set -e

# Simple, reliable desktop integration for Deb of Death packages
if [ "$1" = "configure" ]; then
    # Update desktop database - this is the most important step
    if command -v update-desktop-database >/dev/null 2>&1; then
        update-desktop-database /usr/share/applications || true
    fi
    
    # Update MIME database if available
    if command -v update-mime-database >/dev/null 2>&1; then
        update-mime-database /usr/share/mime || true  
    fi
    
    # Ensure proper permissions on desktop files
    chmod 644 /usr/share/applications/*.desktop 2>/dev/null || true
fi

exit 0
"""
                    postinst_file = debian_dir / "postinst"
                    postinst_file.write_text(postinst_content)
                    postinst_file.chmod(0o755)
                    
                    # Create simple postrm script for cleanup
                    postrm_content = """#!/bin/bash
set -e

# Cleanup desktop database after package removal
if [ "$1" = "remove" ] || [ "$1" = "purge" ]; then
    if command -v update-desktop-database >/dev/null 2>&1; then
        update-desktop-database /usr/share/applications || true
    fi
fi

exit 0
"""
                    postrm_file = debian_dir / "postrm"
                    postrm_file.write_text(postrm_content)
                    postrm_file.chmod(0o755)
                
                self.progress_updated.emit(40, "Copying executable...")
                
                # Create installation directory structure
                install_dir = package_dir / "usr" / "bin"
                install_dir.mkdir(parents=True)
                
                # Copy executable
                executable_name = Path(self.executable_path).name
                dest_executable = install_dir / executable_name
                shutil.copy2(self.executable_path, dest_executable)
                
                # Set executable permissions
                dest_executable.chmod(stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH)
                
                self.progress_updated.emit(60, "Creating desktop entry...")
                
                # Create desktop entry if requested
                if self.package_data.get('create_desktop_entry', False):
                    self._create_desktop_entry(package_dir, executable_name)
                
                self.progress_updated.emit(80, "Building package...")
                
                # Build the package
                output_file = Path(self.output_dir) / f"{self.package_data['name']}_{self.package_data['version']}.deb"
                
                self.progress_updated.emit(85, "Running dpkg-deb...")
                
                result = subprocess.run([
                    'dpkg-deb', '--build', str(package_dir), str(output_file)
                ], capture_output=True, text=True)
                
                if result.returncode == 0:
                    self.progress_updated.emit(95, "Setting file permissions...")
                    # Set proper permissions so _apt user can read the file
                    output_file.chmod(0o644)
                    
                    self.progress_updated.emit(100, "Package created successfully!")
                    self.build_completed.emit(True, f"Package created: {output_file}")
                else:
                    self.build_completed.emit(False, f"Build failed: {result.stderr}")
                    
        except Exception as e:
            self.build_completed.emit(False, f"Error: {str(e)}")
    
    def _generate_control_file(self) -> str:
        """Generate the DEBIAN/control file content"""
        control_content = f"""Package: {self.package_data['name']}
Version: {self.package_data['version']}
Section: {self.package_data['section']}
Priority: {self.package_data['priority']}
Architecture: {self.package_data['architecture']}
Maintainer: {self.package_data['maintainer']}
Description: {self.package_data['short_description']}
 {self.package_data['long_description']}"""
        
        # Add optional fields only if they have valid values
        homepage = self.package_data.get('homepage', '').strip()
        if homepage and homepage != 'https://example.com':
            control_content += f"\nHomepage: {homepage}"
        
        depends = self.package_data.get('depends', '').strip()
        if depends and depends.lower() not in ['none', 'n/a', '']:
            # Clean up dependencies - remove invalid entries
            deps = [dep.strip() for dep in depends.split(',') if dep.strip() and dep.strip().lower() != 'none']
            if deps:
                control_content += f"\nDepends: {', '.join(deps)}"
        
        return control_content + "\n"
    
    def _create_desktop_entry(self, package_dir: Path, executable_name: str):
        """Create a standards-compliant desktop entry file for guaranteed menu integration"""
        desktop_dir = package_dir / "usr" / "share" / "applications"
        desktop_dir.mkdir(parents=True, exist_ok=True)
        
        # Clean package name for file naming (must be valid filename)
        clean_name = self.package_data['name'].replace('_', '-').replace(' ', '-').lower()
        # Remove any invalid characters
        clean_name = re.sub(r'[^a-z0-9\-\.]', '', clean_name)
        
        # Determine appropriate category based on package section
        section_to_category = {
            'games': 'Game',
            'graphics': 'Graphics', 
            'net': 'Network',
            'devel': 'Development',
            'admin': 'System',
            'utils': 'Utility',
            'text': 'Office',
            'sound': 'AudioVideo',
            'web': 'Network',
            'misc': 'Utility',
            'science': 'Education',
            'education': 'Education'
        }
        
        primary_category = section_to_category.get(self.package_data['section'], 'Utility')
        
        # Create minimal but complete desktop entry following freedesktop.org spec
        desktop_content = f"""[Desktop Entry]
Version=1.0
Type=Application
Name={self.package_data['name']}
Comment={self.package_data['short_description']}
Exec=/usr/bin/{executable_name}
Icon=utilities-terminal
Terminal=false
Categories={primary_category};
StartupNotify=true
"""
        
        # Write the desktop file
        desktop_file = desktop_dir / f"{clean_name}.desktop"
        desktop_file.write_text(desktop_content, encoding='utf-8')
        
        # Set correct permissions (readable by all, writable by owner)
        desktop_file.chmod(0o644)
        
        # Create a verification file for debugging
        verification_content = f"""# Desktop Entry Verification for {self.package_data['name']}
Desktop file created: {desktop_file}
Target executable: /usr/bin/{executable_name}
Category: {primary_category}
Package section: {self.package_data['section']}

# Verification commands:
# ls -la /usr/share/applications/{clean_name}.desktop
# desktop-file-validate /usr/share/applications/{clean_name}.desktop
# cat /usr/share/applications/{clean_name}.desktop
"""
        
        verification_file = package_dir / "usr" / "share" / "doc" / self.package_data['name'] / "desktop-entry-info.txt"
        verification_file.parent.mkdir(parents=True, exist_ok=True)
        verification_file.write_text(verification_content)
        verification_file.chmod(0o644)


class AnimatedButton(QPushButton):
    """Custom button with hover animations"""
    
    def __init__(self, text: str, parent=None):
        super().__init__(text, parent)
        self.setMinimumHeight(45)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        
        # Animation setup
        self.animation = QPropertyAnimation(self, b"geometry")
        self.animation.setDuration(200)
        self.animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        
    def enterEvent(self, event):
        """Animate on hover enter"""
        super().enterEvent(event)
        self.setStyleSheet(self.styleSheet().replace("background: qlineargradient", "background: qlineargradient"))
        
    def leaveEvent(self, event):
        """Animate on hover leave"""
        super().leaveEvent(event)


class ModernLineEdit(QLineEdit):
    """Custom line edit with modern styling"""
    
    def __init__(self, placeholder: str = "", parent=None):
        super().__init__(parent)
        self.setPlaceholderText(placeholder)
        self.setMinimumHeight(40)


class DebPackagerApp(QMainWindow):
    """Main application window for Debian package creation"""
    
    def __init__(self):
        super().__init__()
        self.builder_thread: Optional[PackageBuilder] = None
        self.executable_path = ""
        self.setup_ui()
        self.apply_styles()
        
    def setup_ui(self):
        """Initialize the user interface"""
        self.setWindowTitle("Deb of Death - Professional Package Creator")
        self.setMinimumSize(640, 480)
        self.resize(1200, 800)
        
        # Central widget with splitter layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(20)
        
        # Create splitter for resizable panels
        splitter = QSplitter(Qt.Orientation.Horizontal)
        main_layout.addWidget(splitter)
        
        # Left panel - Package configuration
        left_panel = self.create_config_panel()
        splitter.addWidget(left_panel)
        
        # Right panel - Preview and build
        right_panel = self.create_build_panel()
        splitter.addWidget(right_panel)
        
        # Set initial splitter sizes
        splitter.setSizes([600, 400])
        
        # Status bar with death theme
        self.statusBar().showMessage("💀 Death's Head Package Creator - Ready to terminate bad packages")
        
    def create_config_panel(self) -> QWidget:
        """Create the left configuration panel"""
        panel = QFrame()
        panel.setFrameStyle(QFrame.Shape.StyledPanel)
        layout = QVBoxLayout(panel)
        layout.setSpacing(15)
        
        # Title
        title = QLabel("💀 Package Configuration")
        title.setObjectName("panel-title")
        layout.addWidget(title)
        
        # Executable selection
        exe_group = QGroupBox("Executable Selection")
        exe_layout = QVBoxLayout(exe_group)
        
        self.exe_path_label = QLabel("No executable selected")
        self.exe_path_label.setObjectName("file-path")
        exe_layout.addWidget(self.exe_path_label)
        
        self.browse_btn = AnimatedButton("📁 Browse for Executable")
        self.browse_btn.clicked.connect(self.browse_executable)
        exe_layout.addWidget(self.browse_btn)
        
        layout.addWidget(exe_group)
        
        # Package metadata
        meta_group = QGroupBox("Package Metadata")
        meta_layout = QGridLayout(meta_group)
        meta_layout.setSpacing(10)
        
        # Package fields
        fields = [
            ("Package Name:", "name", "my-application"),
            ("Version:", "version", "1.0.0"),
            ("Maintainer:", "maintainer", "Your Name <your.email@example.com>"),
            ("Short Description:", "short_description", "Brief description of your application"),
            ("Homepage:", "homepage", "https://example.com (optional)"),
            ("Dependencies:", "depends", "python3, libc6 (optional - leave empty if none)"),
        ]
        
        self.fields = {}
        for i, (label, key, placeholder) in enumerate(fields):
            lbl = QLabel(label)
            lbl.setObjectName("field-label")
            meta_layout.addWidget(lbl, i, 0)
            
            edit = ModernLineEdit(placeholder)
            edit.setObjectName("field-input")
            self.fields[key] = edit
            meta_layout.addWidget(edit, i, 1)
        
        # Dropdowns
        dropdown_row = len(fields)
        
        # Section dropdown
        meta_layout.addWidget(QLabel("Section:"), dropdown_row, 0)
        self.section_combo = QComboBox()
        self.section_combo.addItems([
            "utils", "admin", "devel", "doc", "libs", "net", "misc", 
            "text", "x11", "games", "graphics", "sound", "web"
        ])
        meta_layout.addWidget(self.section_combo, dropdown_row, 1)
        
        # Priority dropdown
        meta_layout.addWidget(QLabel("Priority:"), dropdown_row + 1, 0)
        self.priority_combo = QComboBox()
        self.priority_combo.addItems(["optional", "standard", "important", "required"])
        meta_layout.addWidget(self.priority_combo, dropdown_row + 1, 1)
        
        # Architecture dropdown
        meta_layout.addWidget(QLabel("Architecture:"), dropdown_row + 2, 0)
        self.arch_combo = QComboBox()
        self.arch_combo.addItems(["amd64", "i386", "armhf", "arm64", "all"])
        meta_layout.addWidget(self.arch_combo, dropdown_row + 2, 1)
        
        layout.addWidget(meta_group)
        
        # Long description
        desc_group = QGroupBox("Detailed Description")
        desc_layout = QVBoxLayout(desc_group)
        
        self.long_desc = QTextEdit()
        self.long_desc.setPlaceholderText("Enter a detailed description of your application...")
        self.long_desc.setMaximumHeight(100)
        desc_layout.addWidget(self.long_desc)
        
        layout.addWidget(desc_group)
        
        # Options
        options_group = QGroupBox("Options")
        options_layout = QVBoxLayout(options_group)
        
        self.create_desktop_entry = QCheckBox("Create desktop entry (.desktop file)")
        self.create_desktop_entry.setChecked(True)
        options_layout.addWidget(self.create_desktop_entry)
        
        layout.addWidget(options_group)
        
        layout.addStretch()
        return panel
    
    def create_build_panel(self) -> QWidget:
        """Create the right build panel"""
        panel = QFrame()
        panel.setFrameStyle(QFrame.Shape.StyledPanel)
        layout = QVBoxLayout(panel)
        layout.setSpacing(15)
        
        # Title
        title = QLabel("⚡ Build & Terminate")
        title.setObjectName("panel-title")
        layout.addWidget(title)
        
        # Preview area
        preview_group = QGroupBox("Package Preview")
        preview_layout = QVBoxLayout(preview_group)
        
        self.preview_text = QTextEdit()
        self.preview_text.setReadOnly(True)
        self.preview_text.setMaximumHeight(200)
        self.preview_text.setPlaceholderText("Package preview will appear here...")
        preview_layout.addWidget(self.preview_text)
        
        self.update_preview_btn = AnimatedButton("🔄 Update Preview")
        self.update_preview_btn.clicked.connect(self.update_preview)
        preview_layout.addWidget(self.update_preview_btn)
        
        layout.addWidget(preview_group)
        
        # Output directory
        output_group = QGroupBox("Output Directory")
        output_layout = QVBoxLayout(output_group)
        
        self.output_path = ModernLineEdit(str(Path.home()))
        output_layout.addWidget(self.output_path)
        
        self.browse_output_btn = AnimatedButton("📂 Choose Output Directory")
        self.browse_output_btn.clicked.connect(self.browse_output_dir)
        output_layout.addWidget(self.browse_output_btn)
        
        layout.addWidget(output_group)
        
        # Build section
        build_group = QGroupBox("Build Package")
        build_layout = QVBoxLayout(build_group)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        build_layout.addWidget(self.progress_bar)
        
        self.progress_label = QLabel("")
        self.progress_label.setObjectName("progress-label")
        build_layout.addWidget(self.progress_label)
        
        self.build_btn = AnimatedButton("💀 Execute Package Build")
        self.build_btn.clicked.connect(self.build_package)
        build_layout.addWidget(self.build_btn)
        
        layout.addWidget(build_group)
        
        # Build log
        log_group = QGroupBox("Build Log")
        log_layout = QVBoxLayout(log_group)
        
        self.build_log = QTextEdit()
        self.build_log.setReadOnly(True)
        self.build_log.setMaximumHeight(150)
        log_layout.addWidget(self.build_log)
        
        layout.addWidget(log_group)
        
        layout.addStretch()
        return panel
    
    def apply_styles(self):
        """Apply modern dark theme styling"""
        self.setStyleSheet("""
            QMainWindow {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, 
                    stop:0 #0f0f23, stop:1 #1a1a2e);
                color: #e6e6fa;
            }
            
            QFrame {
                background: rgba(255, 255, 255, 0.05);
                border: 1px solid rgba(255, 255, 255, 0.1);
                border-radius: 12px;
                margin: 2px;
            }
            
            QGroupBox {
                font-weight: 600;
                font-size: 14px;
                color: #4fc3f7;
                border: 2px solid rgba(79, 195, 247, 0.3);
                border-radius: 8px;
                margin-top: 8px;
                padding-top: 8px;
            }
            
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 8px 0 8px;
                color: #4fc3f7;
                background: rgba(15, 15, 35, 0.9);
            }
            
            #panel-title {
                font-size: 24px;
                font-weight: 700;
                color: #ffffff;
                margin-bottom: 10px;
                padding: 10px;
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #4fc3f7, stop:1 #29b6f6);
                border-radius: 8px;
                margin: 0px;
            }
            
            #field-label {
                font-weight: 600;
                color: #b39ddb;
                font-size: 13px;
            }
            
            #field-input, QLineEdit, QTextEdit {
                background: rgba(255, 255, 255, 0.08);
                border: 2px solid rgba(255, 255, 255, 0.1);
                border-radius: 8px;
                padding: 8px 12px;
                font-size: 13px;
                color: #ffffff;
                selection-background-color: #4fc3f7;
            }
            
            #field-input:focus, QLineEdit:focus, QTextEdit:focus {
                border-color: #4fc3f7;
                background: rgba(79, 195, 247, 0.1);
            }
            
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #4fc3f7, stop:1 #29b6f6);
                border: none;
                border-radius: 8px;
                color: #ffffff;
                font-weight: 600;
                font-size: 14px;
                padding: 12px 20px;
                min-height: 20px;
            }
            
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #29b6f6, stop:1 #0288d1);
                transform: translateY(-1px);
            }
            
            QPushButton:pressed {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #0277bd, stop:1 #01579b);
            }
            
            QPushButton:disabled {
                background: rgba(255, 255, 255, 0.1);
                color: rgba(255, 255, 255, 0.5);
            }
            
            QComboBox {
                background: rgba(255, 255, 255, 0.08);
                border: 2px solid rgba(255, 255, 255, 0.1);
                border-radius: 8px;
                padding: 8px 12px;
                color: #ffffff;
                font-size: 13px;
                min-height: 20px;
            }
            
            QComboBox:focus {
                border-color: #4fc3f7;
            }
            
            QComboBox::drop-down {
                border: none;
                width: 30px;
            }
            
            QComboBox::down-arrow {
                image: none;
                border: 2px solid #4fc3f7;
                width: 6px;
                height: 6px;
                background: #4fc3f7;
            }
            
            QCheckBox {
                color: #e6e6fa;
                font-size: 13px;
                spacing: 8px;
            }
            
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
                border: 2px solid rgba(255, 255, 255, 0.3);
                border-radius: 4px;
                background: rgba(255, 255, 255, 0.05);
            }
            
            QCheckBox::indicator:checked {
                background: #4fc3f7;
                border-color: #4fc3f7;
            }
            
            QProgressBar {
                background: rgba(255, 255, 255, 0.1);
                border: 1px solid rgba(255, 255, 255, 0.2);
                border-radius: 8px;
                text-align: center;
                color: #ffffff;
                font-weight: 600;
            }
            
            QProgressBar::chunk {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #4fc3f7, stop:1 #29b6f6);
                border-radius: 6px;
                margin: 2px;
            }
            
            #file-path {
                color: #81c784;
                font-family: 'Courier New', monospace;
                font-size: 12px;
                padding: 8px;
                background: rgba(129, 199, 132, 0.1);
                border-radius: 4px;
                border-left: 4px solid #81c784;
            }
            
            #progress-label {
                color: #ffb74d;
                font-weight: 600;
                font-size: 13px;
            }
            
            QSplitter::handle {
                background: rgba(255, 255, 255, 0.1);
                width: 3px;
                border-radius: 1px;
            }
            
            QSplitter::handle:hover {
                background: #4fc3f7;
            }
            
            QStatusBar {
                background: rgba(0, 0, 0, 0.2);
                color: #b39ddb;
                border-top: 1px solid rgba(255, 255, 255, 0.1);
            }
        """)
    
    def browse_executable(self):
        """Open file dialog to select executable"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, 
            "Select Executable", 
            str(Path.home()), 
            "Executable Files (*)"
        )
        
        if file_path:
            self.executable_path = file_path
            self.exe_path_label.setText(f"🎯 {Path(file_path).name}")
            self.statusBar().showMessage(f"💀 Target acquired: {file_path}")
            self.update_preview()
    
    def browse_output_dir(self):
        """Open dialog to select output directory"""
        dir_path = QFileDialog.getExistingDirectory(
            self, 
            "Select Output Directory", 
            self.output_path.text()
        )
        
        if dir_path:
            self.output_path.setText(dir_path)
    
    def update_preview(self):
        """Update the package preview"""
        if not self.executable_path:
            self.preview_text.setPlainText("⚠️ Please select an executable first.")
            return
        
        package_data = self.get_package_data()
        
        preview = f"""Package: {package_data['name']}
Version: {package_data['version']}
Architecture: {package_data['architecture']}
Maintainer: {package_data['maintainer']}
Section: {package_data['section']}
Priority: {package_data['priority']}
Description: {package_data['short_description']}

📁 Executable: {Path(self.executable_path).name}
📂 Install Path: /usr/bin/{Path(self.executable_path).name}
🎯 Output: {package_data['name']}_{package_data['version']}.deb

{'✅ Desktop entry will be created' if self.create_desktop_entry.isChecked() else '❌ No desktop entry'}
"""
        
        self.preview_text.setPlainText(preview)
    
    def get_package_data(self) -> dict:
        """Collect package data from form fields"""
        return {
            'name': self.fields['name'].text() or 'my-application',
            'version': self.fields['version'].text() or '1.0.0',
            'maintainer': self.fields['maintainer'].text() or 'Unknown',
            'short_description': self.fields['short_description'].text() or 'No description',
            'long_description': self.long_desc.toPlainText() or 'No detailed description available.',
            'homepage': self.fields['homepage'].text(),
            'depends': self.fields['depends'].text(),
            'section': self.section_combo.currentText(),
            'priority': self.priority_combo.currentText(),
            'architecture': self.arch_combo.currentText(),
            'create_desktop_entry': self.create_desktop_entry.isChecked()
        }
    
    def build_package(self):
        """Start the package building process"""
        if not self.executable_path:
            QMessageBox.warning(self, "Error", "Please select an executable first.")
            return
        
        if not self.fields['name'].text():
            QMessageBox.warning(self, "Error", "Please enter a package name.")
            return
        
        # Validate package name
        package_name = self.fields['name'].text()
        if not package_name.replace('-', '').replace('.', '').isalnum() or package_name != package_name.lower():
            QMessageBox.warning(
                self, "Invalid Package Name", 
                "Package name should contain only lowercase letters, numbers, hyphens, and dots."
            )
            return
        
        # Validate dependencies
        depends = self.fields['depends'].text().strip()
        if depends:
            invalid_deps = []
            for dep in depends.split(','):
                dep = dep.strip().lower()
                if dep in ['none', 'n/a', 'null', 'empty']:
                    invalid_deps.append(dep)
            
            if invalid_deps:
                QMessageBox.warning(
                    self, "Invalid Dependencies", 
                    f"Found invalid dependency names: {', '.join(invalid_deps)}\n"
                    "Either leave the dependencies field empty or specify real package names like 'python3, libc6'"
                )
                return
        
        # Validate dpkg-deb availability
        try:
            subprocess.run(['dpkg-deb', '--version'], capture_output=True, check=True)
        except (subprocess.CalledProcessError, FileNotFoundError):
            QMessageBox.critical(
                self, 
                "Missing Dependency", 
                "dpkg-deb is not installed. Please install it:\nsudo apt install dpkg-dev"
            )
            return
        
        # Disable build button and show progress
        self.build_btn.setEnabled(False)
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.build_log.clear()
        
        # Start build thread
        package_data = self.get_package_data()
        output_dir = self.output_path.text() or str(Path.home())
        
        self.builder_thread = PackageBuilder(package_data, self.executable_path, output_dir)
        self.builder_thread.progress_updated.connect(self.on_progress_updated)
        self.builder_thread.build_completed.connect(self.on_build_completed)
        self.builder_thread.start()
    
    def on_progress_updated(self, progress: int, message: str):
        """Handle progress updates from build thread"""
        self.progress_bar.setValue(progress)
        self.progress_label.setText(message)
        self.build_log.append(f"[{progress}%] {message}")
        
    def on_build_completed(self, success: bool, message: str):
        """Handle build completion"""
        self.progress_bar.setVisible(False)
        self.build_btn.setEnabled(True)
        self.progress_label.setText("")
        
        if success:
            self.build_log.append(f"💀 EXECUTION SUCCESSFUL: {message}")
            QMessageBox.information(self, "Package Terminated Successfully", message)
            self.statusBar().showMessage("💀 Package executed successfully - Death's work is done!")
        else:
            self.build_log.append(f"💥 EXECUTION FAILED: {message}")
            QMessageBox.critical(self, "Execution Failed", message)
            self.statusBar().showMessage("💀 Package execution failed - Try again!")


def main():
    """Main application entry point"""
    app = QApplication(sys.argv)
    app.setStyle('Fusion')  # Modern look across platforms
    
    # Set application metadata
    app.setApplicationName("Deb of Death - Professional Package Creator")
    app.setApplicationVersion("1.0.0")
    app.setOrganizationName("Death's Head Software")
    
    # Create and show splash screen
    splash = DebOfDeathSplash.create_splash()
    
    if splash:
        # Show splash with loading sequence
        DebOfDeathSplash.show_splash_sequence(splash, app)
    
    # Create main window
    window = DebPackagerApp()
    
    # Show main window and dismiss splash
    window.show()
    if splash:
        splash.finish(window)
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
